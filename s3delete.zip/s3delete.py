from crhelper import CfnResource
import boto3
import logging
import json

logger = logging.getLogger(__name__)
helper = CfnResource(json_logging=False, log_level='DEBUG', boto_level='CRITICAL', sleep_on_delete=120, ssl_verify=None)


def handler(event, context):
    logger.info("REQUEST RECEIVED:\n" + json.dumps(event))
    helper(event, context)



@helper.create
def create(event, context):
    logger.info("Got Create")
    pass

@helper.update
def update(event, context):
    logger.info("Got Update")
    pass

@helper.delete
def s3_empty_bucket(event, context):
    logger.info("Got Delete")
    s3bucketName = event['ResourceProperties']['s3bucketName']
    AthenaresultsbucketName = event['ResourceProperties']['AthenaresultsbucketName']
    s3 = boto3.resource('s3')
    bucket1 = s3.Bucket(s3bucketName)
    bucket1.objects.all().delete()
    bucket2 = s3.Bucket(AthenaresultsbucketName)
    bucket2.objects.all().delete()
